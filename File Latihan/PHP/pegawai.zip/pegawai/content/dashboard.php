<?php
   if(!defined('INDEX')) die("");
?>

<h1>Selamat Datang di Aplkasi Manajemen Pegawai</h1>
<h3>Anda login sebagai Administrator</h3>